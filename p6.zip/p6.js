/* 
    CIT 281 Project 6
    Name: Catherine Nolan 
*/ 

class Shape {
    constructor (arrSides = []) {
        this.sides = arrSides; 
    }
    perimeter = () => { return this.sides.length >= 1 ? 
    this.sides.reduce ((sum, num) => sum + num) : 0}; 
}


//console.log(new Shape([5, 10]).perimeter());  // 15
//console.log(new Shape([1, 2, 3, 4, 5]).perimeter()); // 15
//console.log(new Shape().perimeter()); // 0

class Rectangle extends Shape {
    constructor (length = 0, width = 0) {
        super ([length, width, length, width]); 
        this.length = length; 
        this.width = width; 
    }
    area = () => this.length * this.width; 
}

//console.log(new Rectangle(4, 4).perimeter());  // 16
//console.log(new Rectangle(4, 4).area());  // 16
//console.log(new Rectangle(5, 5).perimeter()); // 20
//console.log(new Rectangle(5, 5).area()); // 25
//console.log(new Rectangle().perimeter()); // 0
//console.log(new Rectangle().area()); // 0


class Triangle extends Shape {
    constructor (sideA = 0, sideB = 0, sideC = 0) {
        super([sideA, sideB, sideC]); 
        this.sideA = sideA; 
        this.sideB = sideB; 
        this.sideC = sideC; 
        this.s = this.perimeter()/2; 
    }
    area = () => Math.sqrt(this.s*(this.s-this.sideA)*(this.s-this.sideB)*(this.s-this.sideC)); 
}

//console.log(new Triangle(3, 4, 5).perimeter());  // 12
//console.log(new Triangle(3, 4, 5).area());  // 6
//console.log(new Triangle().perimeter()); // 0
//console.log(new Triangle().area()); // 0
 
const data = [[3, 4], [5, 5], [3, 4, 5,], [10], [0]]; 
for (const d of data) {
    var x; 
    switch (d.length) {
        case 2: 
            x = new Rectangle (...d); 
            if (x.length == x.width) console.log (`Square with sides ${d.toString()} has perimeter of ${x.perimeter()} and area ${x.area()}`); 
            else console.log (`Rectangle with sides ${d.toString()} has perimiter of ${x.perimeter()} and area ${x.area()}`); 
            break; 
        case 3: 
            x = new Triangle (...d); 
            console.log (`Triangle with sides ${d.toString()} has perimeter of ${x.perimeter()} and area ${x.area()}`); 
            break; 
        default : 
        console.log(`Shape with ${d.length} side unsupported`);  
    }
}